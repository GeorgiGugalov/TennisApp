﻿namespace TennisApp.Data.Models.Enums
{
    public enum Level
    {
        Begginer,
        Intermediate,
        Advanced,
        Professional
    }
}
