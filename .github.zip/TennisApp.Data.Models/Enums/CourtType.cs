﻿namespace TennisApp.Data.Models.Enums
{
    public enum CourtType
    {
        Hard,
        Clay,
        Grass,
    }
}
