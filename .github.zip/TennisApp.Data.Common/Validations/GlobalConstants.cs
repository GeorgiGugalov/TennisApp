﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TennisApp.Common.Validations
{
    public class GlobalConstants
    {
        public const string SystemName = "Tennis_Club";

        public const string AdministratorRoleName = "Administrator";
    }
}
